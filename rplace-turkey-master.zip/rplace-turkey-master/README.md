# rplace-turkey

This repo is heavily based on works of [tux community](https://www.reddit.com/r/placetux/) <sub>([here](https://gist.github.com/humanova/3979a4068340444ac76503a56211856a)'s the deleted script of [ryleu](https://github.com/ryleu)). </sub> 

I made slight changes in the original script for my comfort. 
[Sercan](https://github.com/srcnalt) added the tile coordinates tooltip.

---
### Emeği geçen çizer ve yazılımcı arkadaşlara teşekkür ediyorum : 

- [Ege](https://www.reddit.com/user/egeesin)
- [Emirhan](https://www.reddit.com/user/emrhnugrl)
- [Berkay](https://github.com/moon-chain)
- [Eren](https://www.reddit.com/u/eren_yordem)
- [Kitsuinox](https://www.reddit.com/user/Kitsuinox)
- [Furkan](https://github.com/yakuthun)
- [Göktuğ](https://www.reddit.com/user/goktug_exe)
- [Turug](https://github.com/tyrone718)

### Yayıncılarla olan iletişimimizde bize yardımcı olan Cordiseps ve Valaska'ya ayrıca teşekkür ederim. 
